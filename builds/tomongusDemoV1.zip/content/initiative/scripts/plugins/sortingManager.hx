import funkin.scripting.PluginsManager;
import funkin.scripts.ScriptGroup;
import funkin.scripts.FunkinScript;

var loadedScripts;

function onLoad() {
    loadedScripts = PluginsManager.loadedScripts;

    initiativePopulate('others');
    initiativePopulate('objects');
}

public function initiativePopulate(path):Void
{
	for (file in Paths.listAllFilesInDirectory('scripts/plugins/$path'))
	{
		if (FunkinScript.isHxFile(file))
		{
			final scriptName = file;
			
			var script = FunkinScript.fromFile(file, scriptName, loadedScripts.scriptShareables);
			if (script.__garbage)
			{
				script = FlxDestroyUtil.destroy(script);
				continue;
			}
			
			loadedScripts.addScript(script, true);
			if (script.exists('onLoad')) script.call('onLoad');
		}
	}
}