package funkin.states;
import haxe.Reflect;
import Type;
import funkin.objects.menu.AmongControls;

var gamepad:FlxGamepad = FlxG.gamepads.lastActive;

var cartridge:FlxSprite;
var cartridgeControls:AmongControls;

function onStateSwitchPost(state:FlxState):Void {
    cartridge = null;
    if (Type.getClassName(Type.getClass(state)) == 'funkin.states.MainMenuState') {
        cartridge = new FlxSprite(1100, 600);
        cartridge.angle = -90;
	    cartridge.loadGraphic(Paths.image('menu/main/cartridge'));
        cartridge.scale.set(0.5, 0.5);
        cartridge.updateHitbox();
        FlxG.state.add(cartridge);
        cartridge.scrollFactor.set();

        cartridgeControls = new AmongControls([
	    	['arrow', 'select'],
	    	['enter', 'conf'],
            ['tab', 'Go to the Initiative']
	    ], false);

        FlxG.state.members[30].visible = false;
        state.add(cartridgeControls);
    }
}

function onUpdate(elapsed) {
    gamepad = FlxG.gamepads.lastActive;
    if (cartridge != null && Type.getClassName(Type.getClass(FlxG.state)) == 'funkin.states.MainMenuState') {
        cartridgeControls.update(elapsed);
        if ((FlxG.mouse.justPressed && FlxG.mouse.overlaps(cartridge)) || FlxG.keys.justPressed.TAB) {
            FlxTween.tween(cartridge, {"x": cartridge.x + 75}, 0.1, {ease: FlxEase.expoOut});
            FlxG.switchState(()->{
                new ScriptedState("initiative/SelectionMenuState");
            });
        }

        if (gamepad != null) {
            if (gamepad.justPressed.X) {
                FlxTween.tween(cartridge, {"x": cartridge.x + 75}, 0.1, {ease: FlxEase.expoOut});
                FlxG.switchState(()->{
                    new ScriptedState("initiative/SelectionMenuState");
                });
            }
        }
        for (touch in FlxG.touches.list) {
            if (touch.justPressed && touch.overlaps(cartridge)) {
                FlxTween.tween(cartridge, {"x": cartridge.x + 75}, 0.1, {ease: FlxEase.expoOut});
                FlxG.switchState(()->{
                    new ScriptedState("initiative/SelectionMenuState");
                });
            }
        }
    }
}