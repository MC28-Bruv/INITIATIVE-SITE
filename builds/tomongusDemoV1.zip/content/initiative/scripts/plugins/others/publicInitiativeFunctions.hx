import funkin.FunkinAssets;
import funkin.scripts.FunkinScript;
import sys.FileSystem;
import Reflect;
import funkin.backend.FallbackState;
import funkin.api.DiscordClient;
import openfl.net.URLLoader;
import openfl.net.URLRequest;
// shit
    // common

    public var initiativeMods = {
        newSuper: null
    }

    public function iHateYou() {
        return initiativeGames;
    }

    public var InitiativePaths = {
        image: function(path, allowMods = true) {
            /*if (FunkinAssets.exists('initiative/' + path + '.png')) return FunkinAssets.getContent('initiative/' + path + '.png');
            if (allowMods) {
                for (mod in Reflect.fields(initiativeMods)) {
                    if (Reflect.field(initiativeMods, mod) != null)
                        if (FunkinAssets.exists('initiative/mods/' + mod + path + '.png')) return FunkinAssets.getContent('initiative/mods/' + mod + path + '.png');
                }
            }
            return null;*/
        },
        map: function(path, allowMods = true) {
            /*if (FunkinAssets.exists('initiative/' + path + '.png')) return FunkinAssets.getContent('initiative/' + path + '.json');
            if (allowMods) {
                for (mod in Reflect.fields(initiativeMods)) {
                    if (Reflect.field(initiativeMods, mod) != null)
                        if (FunkinAssets.exists('initiative/mods/' + mod + path + '.json')) return FunkinAssets.getContent('initiative/mods/' + mod + path + '.json');
                }
            }
            return null;*/
        },
        script: function(path, allowMods = true) {
            /*if (FunkinAssets.exists('initiative/' + path + '.png')) return FunkinAssets.getContent('initiative/' + path + '.hx');
            if (allowMods) {
                for (mod in Reflect.fields(initiativeMods)) {
                    if (Reflect.field(initiativeMods, mod) != null)
                        if (FunkinAssets.exists('initiative/mods/' + mod + path + '.hx')) return FunkinAssets.getContent('initiative/mods/' + mod + path + '.hx');
                }
            }*/
            trace('hi');
            return null;
        }
    }

    // new soup
    public var newSuperVariables = {
        curMap: '1-1',
        map: {
            displayName: 'Test',
            objects: []
        }
    }

    public function initMapScript() {
    	if (FunkinAssets.exists('initiative/super/new/maps/' + newSuperVariables.curMap + '.hx'))
    	{
            var path = FunkinScript.getPath('initiative/super/new/maps/' + newSuperVariables.curMap);
    		var newScript = FunkinScript.fromFile(path + '.hx', newSuperVariables.curMap);
            if (newScript == null) newScript = FunkinScript.fromFile(path + '.hxs', newSuperVariables.curMap);
            if (newScript == null) newScript = FunkinScript.fromFile(path + '.hscript', newSuperVariables.curMap);
            if (newScript == null) FlxG.switchState(() -> new FallbackState('Failed to load the map script for World ' + newSuperVariables.curMap + ', please atleast make a dummy script in your mod folder.', () -> FlxG.switchState(new ScriptedState("initiative/SelectionMenuState"))));

            newScript.set('curMap', newSuperVariables.curMap);
            newScript.set('gameMap', newSuperVariables.map);
            newScript.set('newSuperObjects', newSuperObjects);
            newScript.set('FunkinAssets', FunkinAssets);

            for (script in FlxG.state.scriptGroup.members) {
                script.set('mapScript', newScript);
            }
            FlxG.state.scriptGroup.members.push(newScript);
    	}
    }

    public function getContentsFromLink(link, callback, binary = false) {
        var loader = new URLLoader();

        loader.dataFormat = "text";
        if (binary) loader.dataFormat = "binary";

        loader.addEventListener("complete", function() {
            callback(loader.data);
        });
        loader.load(new URLRequest(link));
    }

function onStateSwitchPost() {
    if (FlxG.state.scriptGroup.members.length != 0) {
        for (script in FlxG.state.scriptGroup.members) {
            script.set('initiativeMods', initiativeMods);
            script.set('InitiativePaths', InitiativePaths);
            script.set('newSuperVariables', newSuperVariables);

            script.set('getContentsFromLink', (link, callback, binary) -> getContentsFromLink(link, callback, binary));

            script.set('map', newSuperVariables.map);
            script.set('initMapScript', () -> initMapScript());
        
            script.executeFunc('onInitiativeLoad');
        }
    }
}

function onUpdate() {
    if (FlxG.state.scriptGroup.members.length != 0) {
        for (script in FlxG.state.scriptGroup.members) {
            script.set('initiativeMods', initiativeMods);
            script.set('InitiativePaths', InitiativePaths);
            script.set('newSuperVariables', newSuperVariables);
            script.set('map', newSuperVariables.map);

            script.set('initMapScript', () -> initMapScript()); 
            
            doDiscordPresenceInitiative(script);
        }
    }
}

function doDiscordPresenceInitiative(script) {
    var thing = '';
    switch (script.name) {
        case 'initiative/SelectionMenuState': thing = 'In the Selection Menu';

        // WAVE 1
            // new soup
            case 'initiative/supervsimpostor/new/PlayState': thing = 'Playing New Super VS Impostor - World '+newSuperVariables.curMap;

            // dave
            case 'initiative/dave/MainMenu': thing = 'Playing Dave\'s Dream Job - Main Menu';
            case 'initiative/dave/GameState': thing = 'Playing Dave\'s Dream Job - Night 1';

            // pinball
            case 'initiative/pinball/Intro': thing = 'Loading...';
            case 'initiative/pinball/MainMenu': thing = 'Playing Tomongus Pinball - Main Menu';
            case 'initiative/pinball/PlayState': thing = 'Playing Tomongus Pinball - In Game';

            // crush
            case 'initiative/crush/PlayState': thing = 'Playing Crewmate Crush - In Game';

        // ???
            default: thing = '???';
    }

    if (thing != '') DiscordClient.changePresence(thing);
}