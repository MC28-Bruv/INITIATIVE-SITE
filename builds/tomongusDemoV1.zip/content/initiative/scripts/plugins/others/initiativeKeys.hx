var initiativeKeys = null;

var initiativeGamepad = null;

function onUpdate() {
    if (FlxG.state.scriptGroup.members.length != 0) {
        for (script in FlxG.state.scriptGroup.members) {
            script.set('InitiativeKeys', initiativeKeys);
            script.set('InitiativeGamepad', initiativeGamepad);
        }
        if (FlxG.state.subState != null) {
            for (script in FlxG.state.subState.scriptGroup.members) {
                script.set('InitiativeKeys', initiativeKeys);
                script.set('InitiativeGamepad', initiativeGamepad);
            }
        }
    }

    updateKeys();
    updateGamepad();
}

function onStateSwitchPost() {
    if (FlxG.state.scriptGroup.members.length != 0) {
        for (script in FlxG.state.scriptGroup.members) {
            script.set('InitiativeKeys', initiativeKeys);
            script.set('InitiativeGamepad', initiativeGamepad);
        }
        if (FlxG.state.subState != null) {
            for (script in FlxG.state.subState.scriptGroup.members) {
                script.set('InitiativeKeys', initiativeKeys);
                script.set('InitiativeGamepad', initiativeGamepad);
            }
        }
    }
}

function updateKeys() {
    initiativeKeys = {
        newSuper: {
            LEFT: FlxG.keys.pressed.A || FlxG.keys.pressed.LEFT,
            RIGHT: FlxG.keys.pressed.D || FlxG.keys.pressed.RIGHT,
            UP: FlxG.keys.pressed.W || FlxG.keys.pressed.UP || FlxG.keys.pressed.SPACE,
            DOWN: FlxG.keys.pressed.D || FlxG.keys.pressed.DOWN
        },
        tomongus: {
            ACCEPT: FlxG.keys.justPressed.SPACE || FlxG.keys.justPressed.ENTER
        }
    };
}

function updateGamepad() {
    var gamepad = FlxG.gamepads.lastActive;
    var leftStickX:Float = 0;
    var leftStickY:Float = 0;
    if (gamepad != null) {
        leftStickX = gamepad.getXAxis(19);
        leftStickY = gamepad.getYAxis(19);
    }

    if (gamepad != null) {
        initiativeGamepad = {
            active: true,
            gamepad: gamepad,
            newSuper: {
                LEFT: (leftStickX <= -0.5) || gamepad.pressed.DPAD_LEFT,
                RIGHT: (leftStickX >= 0.5) || gamepad.pressed.DPAD_RIGHT,
                UP: gamepad.justPressed.A || (leftStickY <= -0.5),
                DOWN: FlxG.keys.anyPressed(["S", "DOWN"])
            }
        };
    } else {
        initiativeGamepad = {
            active: false,
            gamepad: null,
            newSuper: {
                LEFT: false,
                RIGHT: false,
                UP: false,
                DOWN: false
            }
        };
    }
}