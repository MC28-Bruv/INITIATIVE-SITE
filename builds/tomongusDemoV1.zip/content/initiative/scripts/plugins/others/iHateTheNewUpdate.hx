// this only fucking exists because i think 1.1.3 broke the scripted states when you use the hot reload keybinds (f5 + f6)
import flixel.addons.transition.FlxTransitionableState;
import flixel.util.FlxStringUtil;

import funkin.scripting.PluginsManager;
import funkin.data.GameFlags;
import funkin.data.Lang;
import funkin.Mods;
import funkin.FunkinAssets;

import Type;

var state;

function onUpdate() {
    #if !debug
	if (!ClientPrefs.inDevMode) return;
	#end
	
    if (Type.getClassName(Type.getClass(FlxG.state)) == 'funkin.scripting.ScriptedState') {
        if (FlxG.state.scriptGroup.members[0] != null) state = FlxG.state.scriptGroup.members[0].name;
        if (state.indexOf('_1') != -1) {
            state = FlxStringUtil.remove(state, '_1');
        }
	    if (FlxG.keys.justPressed.F1) {
	    	FlxTransitionableState.skipNextTransIn = FlxTransitionableState.skipNextTransOut = true;
	    	FlxG.switchState(new ScriptedState(state));
	    }

        if (FlxG.keys.justPressed.F2) {
	    	FlxG.signals.preStateCreate.addOnce((state) -> {
	    		FunkinAssets.cache.clearStoredMemory();
	    		FunkinAssets.cache.clearUnusedMemory();
	    	});
	    	PluginsManager.populate();
	    	GameFlags.getAwards(true);
	    	Lang.reloadLangFile();
	    	FlxTransitionableState.skipNextTransIn = FlxTransitionableState.skipNextTransOut = true;
	    	FlxG.switchState(new ScriptedState(state));
			
	    	Mods.currentModConfig = Mods.loadTopModConfig();
	    }
    }
}