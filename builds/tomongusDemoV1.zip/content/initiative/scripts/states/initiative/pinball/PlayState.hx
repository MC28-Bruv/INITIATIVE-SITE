import funkin.FunkinAssets;
import flixel.addons.transition.FlxTransitionableState;
import flixel.util.FlxSave;
import funkin.api.DiscordClient;

var tomongusBall;

var camTop:FlxCamera;
var camMain:FlxCamera;
var pinballMouse;
var tomongusRot = 1;

var level = [];

var score = 0;
var highscore;

var scoreText;

var nextButton;

function onCreate() {
    if (FlxG.sound.music = null) FlxG.sound.playMusic(Paths.music("tomongusplay"), 0.7, true);
    highscore = FlxG.save.data.initiative.pinball.score;

    if (highscore == null) {
        FlxG.save.data.initiative.pinball.score = 0;
        FlxG.save.flush();
    }

    FlxG.mouse.visible = false;

    setSystemShit();

    loadMainShit();

    buildLevel();
    makeTheBall();
    loadTopLayer();
}

function setSystemShit() {
    FlxG.worldBounds.set(0, -100, FlxG.width * 2, FlxG.height * 2);
}

function loadMainShit() {
    camMain = new FlxCamera();
	camMain.bgColor = 0xFFCC6666;
    FlxG.cameras.add(camMain, false);

    camTop = new FlxCamera();
	camTop.bgColor = 0x00FFFFFF;
    FlxG.cameras.add(camTop, true);
}

var backButton;

function loadTopLayer() {

    var frag:String = Paths.getTextFromFile('shaders/vhs.frag');
    shader = new FlxRuntimeShader(frag);
    shader.setInt('uniform',3);
    shader.setFloat('uInterlace',3);
    if (ClientPrefs.shaders) camMain.filters = [new openfl.filters.ShaderFilter(shader)];
    if (ClientPrefs.shaders) camTop.filters = [new openfl.filters.ShaderFilter(shader)];

    scoreText = new FlxText(455, 672, 0, 'test', 20);
    scoreText.setBorderStyle(FlxTextBorderStyle.OUTLINE, FlxColor.BLACK, 2, 1);
    add(scoreText);

    nextButton = new FlxSprite(1000, 600).makeGraphic(100, 50, FlxColor.PINK);
    add(nextButton);
    nextText = new FlxText(1000, 600, 0, 'NEXT', 20);
    add(nextText);

    backButton = new FlxSprite(1150, 15).loadGraphic(Paths.image('menu/common/reset'));
    backButton.scale.set(0.5, 0.5);
    backButton.updateHitbox();
    add(backButton);

    pinballMouse = new FlxSprite().loadGraphic(Paths.image('pinball/cursor'));
    pinballMouse.antialiasing = false;
    pinballMouse.scale.set(2, 2);
    #if mobile
    pinballMouse.visible = false;
    #end
    add(pinballMouse);
    var blackBarA = new FlxSprite().makeGraphic((FlxG.width - 256 * 3) / 3, FlxG.height, FlxColor.BLACK);
    add(blackBarA);
    var blackBarB = new FlxSprite(FlxG.width - blackBarA.width, 0).makeGraphic(((FlxG.width - 256 * 3) + 100) / 3, FlxG.height, FlxColor.BLACK);
    add(blackBarB);
}

function onUpdate() {
    tomongusBall.angle += tomongusRot;

    if (highscore < score && highscore != score) {
        FlxG.save.data.initiative.pinball.score = score;
        FlxG.save.flush();
        highscore = FlxG.save.data.initiative.pinball.score;
    }
        
    scoreText.text = 'Score: '+score+'\nHighscore:'+highscore;
    pinballMouse.visible = true;

    if (controls.BACK) {
        FlxTween.tween(FlxG.sound.music, {"volume": 0}, 0.5);
        FlxG.switchState(()->{
            new ScriptedState("initiative/pinball/MainMenu");
        });
    }
    pinballMouse.x = FlxG.mouse.x;
    pinballMouse.y = FlxG.mouse.y;

    for (obj in level) {
        if (FlxG.collide(tomongusBall, obj)) {
            score += 100;
            var pop = FlxG.sound.load(Paths.sound('cosmicubePop'));
            pop.pitch = FlxG.random.float(0.8, 1.2);
            pop.play();

            if (FlxG.random.bool()) 
                tomongusRot = FlxG.random.float(1, 5);
            else
                tomongusRot = FlxG.random.float(-5, -1);
        }
    }

    if (tomongusBall.y >= FlxG.height) {
        FlxTransitionableState.skipNextTransIn = FlxTransitionableState.skipNextTransOut = true;
		FlxG.resetState();
    }

    if (controls.ACCEPT) {
        if (tomongusBall.y >= 624) pushTomongus(false);
    }

    if (FlxG.mouse.overlaps(nextButton)) {
        if (FlxG.mouse.justPressed) {
            var mapPack = FlxG.save.data.initiative.pinball.mapPack;
            if (FlxG.save.data.initiative.pinball.mapNum != mapPack.length - 1) {
                FlxG.save.data.initiative.pinball.mapNum += 1;
                FlxG.save.data.initiative.pinball.map = mapPack[FlxG.save.data.initiative.pinball.mapNum];
                FlxG.switchState(()->{
                    new ScriptedState("initiative/pinball/PlayState");
                });
            }
        }
    }

    for (touch in FlxG.touches.list) {
        if (touch.justPressed) {
            if (tomongusBall.y >= 624) pushTomongus(false);
        }
        if (touch.overlaps(nextButton)) {
            var mapPack = FlxG.save.data.initiative.pinball.mapPack;
            if (FlxG.save.data.initiative.pinball.mapNum != mapPack.length - 1) {
                FlxG.save.data.initiative.pinball.mapNum += 1;
                FlxG.save.data.initiative.pinball.map = mapPack[FlxG.save.data.initiative.pinball.mapNum];
                FlxG.switchState(()->{
                    new ScriptedState("initiative/pinball/PlayState");
                });
            }
        }
        if (touch.overlaps(backButton)) {
            var mapPack = FlxG.save.data.initiative.pinball.mapPack;
            FlxTween.tween(FlxG.sound.music, {"volume": 0}, 0.5);
            FlxG.switchState(()->{
                new ScriptedState("initiative/pinball/MainMenu");
            });
        }
    }
}

function buildLevel() {
    var tileHeight = 48;
    var levelfile = CoolUtil.coolTextFile(FlxG.save.data.initiative.pinball.path + '/maps/' + FlxG.save.data.initiative.pinball.map + '.txt');
    var finalLevel = [];
    var bottomA = '3CCCC7####8CCCC4';
    var bottomB = '00000B####900000';
    var solidKey = [
        '1','2','3','4','5','6','7','8','9',
        'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'
    ];
    
    for (line in levelfile) {
        if (line != levelfile[0]) finalLevel.push(line);
    }
    finalLevel.push(bottomA);
    finalLevel.push(bottomB);

    var mainThing = 0;
    for (line in finalLevel) {
        var thing = 0;
        for (symbol in 0...line.length) {
            var letter:String = line.charAt(symbol);
            var sprite = new FlxSprite((thing * tileHeight) + ((FlxG.width - 256 * 3) / 3), mainThing * tileHeight).loadGraphic(FunkinAssets.getGraphic(FlxG.save.data.initiative.pinball.path + '/images/' + levelfile[0] + '/' + letter + '.png'));
            sprite.antialiasing = false;
            sprite.setGraphicSize(tileHeight, tileHeight);
            sprite.immovable = true;
            sprite.updateHitbox();
            add(sprite);
            if (solidKey.contains(letter)) level.push(sprite);
            thing += 1;
        }
        mainThing += 1;
    }
}

function makeTheBall() {
    tomongusBall = new FlxSprite(520, 100).loadGraphic(Paths.image('pinball/tomongusBall'));
    if (FunkinAssets.exists(FlxG.save.data.initiative.pinball.path + '/images/tomongusBall.png')) tomongusBall.loadGraphic(FunkinAssets.getGraphic(FlxG.save.data.initiative.pinball.path + '/images/tomongusBall.png'));
    tomongusBall.updateHitbox();
    tomongusBall.setGraphicSize(48, 48);
    tomongusBall.acceleration.y = 500;
    tomongusBall.elasticity = 1;
    tomongusBall.antialiasing = false;
    pushTomongus(true);

    add(tomongusBall);
}

function pushTomongus(banana) {
    if (FlxG.random.bool()) {
        tomongusRot = FlxG.random.float(1, 5);
        tomongusBall.velocity.x = FlxG.random.float(300, 500);
    } else {
        tomongusRot = FlxG.random.float(-5, -1);
        tomongusBall.velocity.x = FlxG.random.float(-300, -500);
    }

    if (banana) 
        tomongusBall.velocity.y = 500;
    else
        tomongusBall.velocity.y = -750;
}