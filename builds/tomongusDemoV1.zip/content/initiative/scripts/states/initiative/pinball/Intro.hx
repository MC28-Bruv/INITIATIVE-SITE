import funkin.api.DiscordClient;

var txt;
#if !mobile
var drive = Sys.executablePath().charAt(0);
#end
#if mobile
var drive = 'C';
#end

var texts = [
    ['Loaded tomongusPinball!', 2.3491957],
    ['Launching...', 3.140195],
    ['Importing class haxe.Reflect...' 6.1982],
    ['Importing class funkin.scripts.FunkinScript...' 6.3259],
    ['Importing class funkin.FunkinAssets...' 6.8183],
    ['Importing class funkin.scripting.PluginsManager...' 7.29184],
    ['Importing class funkin.api.DiscordClient...' 8.194172],
    ['Opening...', 9.238237],
    ['_hide', 10.4882761],
    ['_load', 11.5938272]
];

function onCreate() {
    txt = new FlxText(((FlxG.width - 256 * 3) / 3) + 25, 25, null, drive + ": Loading tomongusPinball.imp", 20);
    txt.color = FlxColor.WHITE;
    txt.font = Paths.font('nintendo-nes-font');
    txt.visible = false;
    add(txt);

    beginStartUp();
}

function beginStartUp() {
    new FlxTimer().start(0.5, ()->{
        txt.visible = true;
        for (text in texts) {
            changeText(text[0], text[1]);
        }
    });
}

function changeText(text, time) {
    new FlxTimer().start(time, ()->{
        if (text.charAt(0) != '_') {
            txt.text += '\n' + drive + ': ' + text;
            if (txt.height >= FlxG.height - 50) txt.text = '\n' + drive + ': ' + text;
        } else {
            if (text == '_hide') txt.visible = false;
            if (text == '_load') {
                FlxG.switchState(()->{
                    new ScriptedState("initiative/pinball/MainMenu");
                });
            }
        }
    });
}

function onUpdate() {
    FlxG.mouse.visible = false;
}