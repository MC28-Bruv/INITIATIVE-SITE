import haxe.Reflect;
import funkin.scripts.FunkinScript;
import funkin.FunkinAssets;
import funkin.scripting.PluginsManager;
import funkin.api.DiscordClient;
import funkin.utils.FileUtil;
import openfl.net.FileFilter;
import openfl.net.FileReference;
import openfl.events.Event;
import sys.io.File;
import sys.FileSystem;
import haxe.io.BytesInput;
import haxe.zip.Reader;
import haxe.io.Path;
import flixel.StringTools;

var pinballMouse;

function onCreate() {
    FlxG.sound.playMusic(Paths.music("selectionwaltz"), 0.7, true);
    FlxG.save.data.initiative.pinball.mapPack = 'base';

    FlxG.mouse.visible = false;

    setSystemShit();

    loadMainShit();

    test();

    loadTopLayer();
}

function setSystemShit() {
    FlxG.worldBounds.set(0, -100, FlxG.width * 2, FlxG.height * 2);
}

var camTop:FlxCamera;
var camMain:FlxCamera;
var titleText;
var pressStart;
var tinymogus;

function loadMainShit() {
    camMain = new FlxCamera();
	camMain.bgColor = 0x00FFFFFF;
    FlxG.cameras.add(camMain, false);

    FlxG.camera.visible = false;

    camTop = new FlxCamera();
	camTop.bgColor = 0x00FFFFFF;
    FlxG.cameras.add(camTop, true);

    pinkBGa = new FlxSprite(10).makeGraphic(FlxG.width, FlxG.height, 0xFFCC6666);
    pinkBGa.camera = camMain;
    pinkBGb = new FlxSprite(10, 200).makeGraphic(FlxG.width, FlxG.height, 0xFFCC7777);
    pinkBGb.camera = camMain;
    pinkBGc = new FlxSprite(10, 500).makeGraphic(FlxG.width, FlxG.height, 0xFFCC8888);
    pinkBGc.camera = camMain;

    titleText = new FlxText(0, 50, null, 'TOMONGUS\nPINBALL');
    titleText.setFormat(Paths.font("vcr.ttf"), 80, FlxColor.WHITE, FlxTextAlign.MIDDLE);
    titleText.screenCenter(FlxAxes.X);
    titleText.camera = camMain;

    pressStart = new FlxText(0, 600, null, 'PRESS START TO BEGIN');
    pressStart.setFormat(Paths.font("vcr.ttf"), 40, FlxColor.WHITE, FlxTextAlign.MIDDLE);
    pressStart.screenCenter(FlxAxes.X);
    pressStart.camera = camMain;

    tinymogus = new FlxSprite().loadGraphic(Paths.image('pinball/tomongusBall'));
    tinymogus.scale.set(8, 8);
    tinymogus.antialiasing = false;
    tinymogus.camera = camMain;

    for (obj in [pinkBGa, pinkBGb, pinkBGc, titleText, pressStart, tinymogus]) add(obj);
}

var backButton;

function loadTopLayer() {

    var frag:String = Paths.getTextFromFile('shaders/vhs.frag');
    shader = new FlxRuntimeShader(frag);
    shader.setInt('uniform',3);
    shader.setFloat('uInterlace',3);
    if (ClientPrefs.shaders) camMain.filters = [new openfl.filters.ShaderFilter(shader)];
    if (ClientPrefs.shaders) camTop.filters = [new openfl.filters.ShaderFilter(shader)];

    backButton = new FlxSprite(1150, 15).loadGraphic(Paths.image('menu/common/reset'));
    backButton.scale.set(0.5, 0.5);
    backButton.updateHitbox();
    add(backButton);

    pinballMouse = new FlxSprite().loadGraphic(Paths.image('pinball/cursor'));
    pinballMouse.antialiasing = false;
    pinballMouse.scale.set(2, 2);
    add(pinballMouse);
    #if mobile
    pinballMouse.visible = false;
    #end

    var blackBarA = new FlxSprite().makeGraphic((FlxG.width - 256 * 3) / 3, FlxG.height, FlxColor.BLACK);
    add(blackBarA);
    var blackBarB = new FlxSprite(FlxG.width - blackBarA.width, 0).makeGraphic(((FlxG.width - 256 * 3) + 100) / 3, FlxG.height, FlxColor.BLACK);
    add(blackBarB);
}

var pinballTomongusTemps;

var borderA;
var borderB;
var borderC;
var borderD;

var lastX:Float = 0;
var lastY:Float = 0;

function onUpdate() {
    pinballMouse.visible = true;

    tinymogus.angle += 5;
    tinymogus.screenCenter();
    for (tomongus in pinballTomongusTemps) {
        tomongus.angle += 10;
        FlxG.collide(tomongus, borderA);
        FlxG.collide(tomongus, borderB);
        FlxG.collide(tomongus, borderC);
        FlxG.collide(tomongus, borderD);
    }
    if (controls.BACK) {
        FlxTween.tween(FlxG.sound.music, {"volume": 0}, 0.5);
        FlxG.switchState(()->{
            new ScriptedState("initiative/SelectionMenuState");
        });
    }
    pinballMouse.x = FlxG.mouse.x;
    pinballMouse.y = FlxG.mouse.y;

    if (FlxG.keys.pressed.Z) {
        var tomongus = makeTomongus();
        tomongus.screenCenter();
        tomongus.velocity.x = FlxG.random.float(-1000, 1000);
        tomongus.velocity.y = FlxG.random.float(-1000, 1000);
        tomongus.angle = 0;
        pinballTomongusTemps.add(tomongus);
    }
    if (FlxG.keys.justPressed.X) {
        for (tomongus in pinballTomongusTemps) {
            FlxTween.tween(tomongus, {"x": 1000, "y": FlxG.height / 2}, 0.1, {
                ease: FlxTween.sineOut, 
                onComplete: function() {
                    tomongus.exists = false;
                    tomongus.alive = false;
                }
            });
        }
    }

    if (InitiativeKeys.tomongus.ACCEPT) {
        pinballMouse.visible = false;
        if (!FlxG.keys.pressed.SHIFT) {
            bytes = FunkinAssets.getBytes("initiative/tomongus.tomo");
            goInGameMobile(bytes);
        } else openSubState(new ScriptedSubstate("TomongusSelect"));
    }
    
    #if mobile
    for (touch in FlxG.touches.list) {
        if (touch.justPressed) {
            openSubState(new ScriptedSubstate("TomongusSelect"));
        }
        
        if (touch.overlaps(backButton)) {
            var mapPack = FlxG.save.data.initiative.pinball.mapPack;
            FlxTween.tween(FlxG.sound.music, {"volume": 0}, 0.5);
            FlxG.switchState(()->{
                new ScriptedState("initiative/pinball/MainMenu");
            });
        }
    }
    #end
}

function test() {
    pinballTomongusTemps = new FlxSpriteGroup();
    add(pinballTomongusTemps);
    borderA = new FlxSprite().makeGraphic((FlxG.width - 256 * 3) / 3, FlxG.height, FlxColor.BLACK);
    borderB = new FlxSprite(FlxG.width - ((FlxG.width - 256 * 3) / 3), 0).makeGraphic(((FlxG.width - 256 * 3) + 100) / 3, FlxG.height, FlxColor.BLACK);
    borderC = new FlxSprite(0, FlxG.height).makeGraphic(FlxG.width, 100, FlxColor.BLACK);
    borderD = new FlxSprite(0, -100).makeGraphic(FlxG.width, 100, FlxColor.BLACK);

    for (border in [borderA, borderB, borderC, borderD]) {
        border.immovable = true;
        border.updateHitbox();
        add(border);
    }
}

function makeTomongus() {
    tomongus = new FlxSprite().loadGraphic(Paths.image('pinball/tomongusBall'));
    tomongus.antialiasing = false;
    tomongus.scale.set(4, 4);
    tomongus.screenCenter();
    tomongus.updateHitbox();
    tomongus.maxVelocity.set(400, 600);
    tomongus.elasticity = 1;
    return(tomongus);
}

function goInGameMobile(zip) {
    var input = new BytesInput(zip);

    var files = Reader.readZip(input);

    if (!FileSystem.exists("initiative/mods/tomongusModTemp"))
        FileSystem.createDirectory("initiative/mods/tomongusModTemp");

    for (file in files) {
        if (StringTools.endsWith(file.fileName, "/")) {
            FileSystem.createDirectory("initiative/mods/tomongusModTemp/" + file.fileName);
            continue;
        }
        File.saveBytes("initiative/mods/tomongusModTemp/" + file.fileName, file.data);
    }

    FlxG.save.data.initiative.pinball.mapNum = 0;

    FlxG.save.data.initiative.pinball.path = "initiative/mods/tomongusModTemp/";
    FlxG.save.data.initiative.pinball.mapPack = CoolUtil.coolTextFile('initiative/mods/tomongusModTemp/base.txt');

    var mapPack = FlxG.save.data.initiative.pinball.mapPack;
    FlxG.sound.music.stop();
    FlxG.save.data.initiative.pinball.map = mapPack[FlxG.save.data.initiative.pinball.mapNum];
    FlxG.switchState(()->{
        new ScriptedState("initiative/pinball/PlayState");
    });
}