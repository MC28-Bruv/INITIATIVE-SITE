import funkin.states.MainMenuState;
import flixel.util.FlxSave;
import funkin.objects.menu.AmongControls;
import flixel.util.FlxGradient;
import openfl.geom.Matrix;
import funkin.scripting.PluginsManager;
import funkin.backend.Logger;
import funkin.api.DiscordClient;
import flixel.text.FlxTextFormat;
import flixel.text.FlxTextFormatMarkerPair;
import funkin.scripts.FunkinScript;

var gamepad:FlxGamepad = FlxG.gamepads.lastActive;

public var bg;
public var selectedGame;
public var iconGame;
public var panela;
public var panelb;

public var gameName;
public var gameDesc;
public var gameCover;

var backButton;
var infoButton;
var curGame = 0;
    public var initiativeGames = [ // i jst wanted to get rid of this broooo :c
        {
            name: "Tomongus Pinball",
            nameTrans: "pinballName",
            description: "We all love Tomongus, right? Well, you can play as them in this pixel art pinball game!",
            descriptionTrans: "pinballDesc",
            image: "pinball",
            icon: "tuesday",
            colorA: 0xFFBB5555,
            colorB: 0xFFCC6666,
            bg: 0xFF331111,
            state: "pinball/Intro",

            info: {
                name: 'Tomongus Pinball',
                description: 'A pinball game where you play as... well, Tomongus.',
                progress: '100%',
                color: 0xFFCC6666,
                image: "pinball",
                wave: "WAVE 1"
            }
        }
    ];

function onCreate() {
    if (FlxG.save.data.initiative == null) {
        FlxG.save.data.initiative = {
            // stuff
        };
    }
    if (FlxG.save.data.initiative.pinball == null) {
        FlxG.save.data.initiative.pinball = {
            score: 0
        };
    }
    if (FlxG.save.data.initiative.curPlayedGames == null) {
        FlxG.save.data.initiative.curPlayedGames = [];
    }
    
    FlxG.camera.bgColor = FlxColor.BLACK;
    #if !mobile
    FlxG.mouse.visible = true;
    #end
    
    FlxG.sound.playMusic(Paths.music("breakfast"), 0.7, true);

    makeInitiativeSelectionMenu();

    var frag:String = Paths.getTextFromFile('shaders/round.frag');
    shader = new FlxRuntimeShader(frag);
    shader.setFloat('depth',-2.5);
    if (ClientPrefs.shaders) FlxG.camera.filters = [new openfl.filters.ShaderFilter(shader)];

    Logger.log('hi im bluecone');
}

var iconBaseY;
var panelBaseY;

function makeInitiativeSelectionMenu() {
    bg = FlxGradient.createGradientFlxSprite(
        FlxG.width + 100, FlxG.height + 100,
        [FlxColor.BLACK, FlxColor.WHITE, FlxColor.BLACK],
        1,
        90,
        true
    );
    bg.updateHitbox();
    bg.scrollFactor.set();
    bg.alpha = 0;

    selectedGame = new FlxSprite();
	selectedGame.loadGraphic(Paths.image('menu/initiative/selection/tab'));
    selectedGame.updateHitbox();
    selectedGame.scale.set(0.5, 0.5);
    selectedGame.screenCenter();
    panelBaseY = selectedGame.y;

    iconGame = new FlxSprite();
	iconGame.loadGraphic(Paths.image('icons/icon-dave'));
	iconFrameWidth = Std.int(iconGame.width * 0.5);
	iconGame.loadGraphic(Paths.image('icons/icon-' + initiativeGames[curGame].icon), true, iconFrameWidth, Std.int(iconGame.height));
	iconGame.animation.add('idle', [0], 0, false);
	iconGame.animation.play('idle');
	iconGame.scrollFactor.set();
    iconGame.screenCenter();
    iconBaseY = iconGame.y;

    panela = new FlxSprite();
	panela.loadGraphic(Paths.image('menu/initiative/selection/panel'));
    panela.updateHitbox();
    panela.scale.set(0.5, 0.5);
    panela.screenCenter();
    panela.x = 650;

    panelb = new FlxSprite();
	panelb.loadGraphic(Paths.image('menu/initiative/selection/panel'));
    panelb.updateHitbox();
    panelb.scale.set(-0.65, 0.65);
    panelb.screenCenter();
    panelb.x = -300;

    gameName = new FlxText(50, 100, 300, Lang.str(initiativeGames[curGame].nameTrans, initiativeGames[curGame].name), 42);
	gameName.setFormat(Paths.font('vcr.ttf'), 42, FlxColor.WHITE, 'center');
	gameName.borderStyle = FlxTextBorderStyle.OUTLINE;
	gameName.borderColor = FlxColor.BLACK;
	gameName.borderSize = 2;

    gameDesc = new FlxText(50, 300, 300, Lang.str(initiativeGames[curGame].descriptionTrans, initiativeGames[curGame].description), 42);
	gameDesc.setFormat(Paths.font('vcr.ttf'), 30, FlxColor.WHITE, 'center');
	gameDesc.borderStyle = FlxTextBorderStyle.OUTLINE;
	gameDesc.borderColor = FlxColor.BLACK;
	gameDesc.borderSize = 2;

    gameCover = new FlxSprite();
	gameCover.loadGraphic(Paths.image('menu/initiative/selection/games/' + initiativeGames[curGame].image));
    gameCover.updateHitbox();
    gameCover.scale.set(0.5, 0.5);
    gameCover.antialiasing = false;
    gameCover.screenCenter();
    gameCover.x = 800;
    gameCover.angle = 5;

    var bottomControls:AmongControls = new AmongControls([
		['arrow', 'select'], // select
		['enter', 'conf'], // confirm
		['esc', 'back'], // back
        ['tab', 'Info']
	], true);
    bottomControls.y -= 5;

    var shadowBottom:FlxSprite = new FlxSprite().makeGraphic(FlxG.width, 500, FlxColor.BLACK);
    shadowBottom.screenCenter();
    shadowBottom.y += bottomControls.height * 14;

    backButton = new FlxSprite(1150, 15).loadGraphic(Paths.image('menu/common/reset'));
    backButton.scale.set(0.5, 0.5);
    backButton.updateHitbox();

    infoButton = new FlxSprite(1150, FlxG.height - 75).loadGraphic(Paths.image('menu/initiative/selection/menuInfo'));
    infoButton.scale.set(1, 1);
    infoButton.updateHitbox();

    for (obj in [bg, selectedGame, iconGame, panela, panelb, gameName, gameDesc, gameCover, backButton, shadowBottom, bottomControls, infoButton]) {
        add(obj);
    }

    selectGame(0, null, true);
}

var moving = false;

function selectGame(num:Int = 0, direction:String, ?intro:Bool = false) {
    curGame = num;

    if (FlxG.save.data.initiative.curPlayedGames.contains(initiativeGames[curGame].name)) {
        if (!intro) {
            moving = true;
            FlxTween.tween(bg, {"alpha": 0}, 0.25, {
                onComplete: function() {
                    bg.color = initiativeGames[curGame].bg;
                    gameName.text = Lang.str(initiativeGames[curGame].nameTrans, initiativeGames[curGame].name);
                    gameName.color = initiativeGames[curGame].colorA;
                    gameDesc.text = Lang.str(initiativeGames[curGame].descriptionTrans, initiativeGames[curGame].description);
                    gameDesc.applyMarkup(gameDesc.text,
			            [
			            	new FlxTextFormatMarkerPair(new FlxTextFormat(0xFFFF4444), "|"),
			            	new FlxTextFormatMarkerPair(new FlxTextFormat(0xFFFFFF44), "#")
			            ]
		            );
                    panela.color = initiativeGames[curGame].colorB;
                    if (initiativeGames[curGame].colorC != null) 
                        panelb.color = initiativeGames[curGame].colorC;
                    else 
                        panelb.color = initiativeGames[curGame].colorB;
                
                    selectedGame.color = initiativeGames[curGame].colorA;

                    gameCover.visible = true;
                    gameCover.loadGraphic(Paths.image('menu/initiative/selection/games/' + initiativeGames[curGame].image));
                    gameCover.screenCenter();
                    gameCover.x = 800;

                    FlxTween.tween(bg, {"alpha": 1}, 0.25);
                }
            });

            if (direction == 'down') {
                FlxTween.tween(iconGame, {"y": iconBaseY + 600}, 0.25, {
                    ease: FlxEase.sineIn,
                    onComplete: function() {
                        iconGame.y = iconBaseY - 600;
                        FlxTween.tween(iconGame, {"y": iconBaseY}, 0.25, {ease: FlxEase.sineIn});

                        iconGame.loadGraphic(Paths.image('icons/icon-' + initiativeGames[curGame].icon));
	                    iconFrameWidth = Std.int(iconGame.width * 0.5);
                        iconGame.loadGraphic(Paths.image('icons/icon-' + initiativeGames[curGame].icon), true, iconFrameWidth, Std.int(iconGame.height));
                    }
                });
                FlxTween.tween(selectedGame, {"y": panelBaseY + 600}, 0.25, {
                    ease: FlxEase.sineOut,
                    onComplete: function() {
                        selectedGame.y = panelBaseY - 600;
                        FlxTween.tween(selectedGame, {"y": panelBaseY}, 0.25, {ease: FlxEase.sineIn, onComplete: moving = false});
                    }
                });
            } else {
                FlxTween.tween(iconGame, {"y": iconBaseY - 600}, 0.25, {
                    ease: FlxEase.sineIn,
                    onComplete: function() {
                        iconGame.y = iconBaseY + 600;
                        FlxTween.tween(iconGame, {"y": iconBaseY}, 0.25, {ease: FlxEase.sineIn});

                        iconGame.loadGraphic(Paths.image('icons/icon-' + initiativeGames[curGame].icon));
	                    iconFrameWidth = Std.int(iconGame.width * 0.5);
                        iconGame.loadGraphic(Paths.image('icons/icon-' + initiativeGames[curGame].icon), true, iconFrameWidth, Std.int(iconGame.height));
                    }
                });
                FlxTween.tween(selectedGame, {"y": panelBaseY - 600}, 0.25, {
                    ease: FlxEase.sineOut,
                    onComplete: function() {
                        selectedGame.y = panelBaseY + 600;
                        FlxTween.tween(selectedGame, {"y": panelBaseY}, 0.25, {ease: FlxEase.sineIn, onComplete: moving = false});
                    }
                });
            }
        } else {
            bg.color = initiativeGames[curGame].bg;
            bg.alpha = 1;
            gameName.text = Lang.str(initiativeGames[curGame].nameTrans, initiativeGames[curGame].name);
            gameName.color = initiativeGames[curGame].colorA;
            gameDesc.text = Lang.str(initiativeGames[curGame].descriptionTrans, initiativeGames[curGame].description);
            panela.color = initiativeGames[curGame].colorB;
            if (initiativeGames[curGame].colorC != null) 
                panelb.color = initiativeGames[curGame].colorC;
            else 
                panelb.color = initiativeGames[curGame].colorB;
            selectedGame.color = initiativeGames[curGame].colorA;

            gameDesc.applyMarkup(gameDesc.text,
			    [
			    	new FlxTextFormatMarkerPair(new FlxTextFormat(0xFFFF4444, true), "|"),
			    	new FlxTextFormatMarkerPair(new FlxTextFormat(0xFFFFFF44, false, true), "#")
			    ]
		    );
        }
    } else {
        var black = FlxColor.BLACK;
        var white = FlxColor.WHITE;
        if (!intro) {
            moving = true;
            FlxTween.tween(bg, {"alpha": 0}, 0.25, {
                onComplete: function() {
                    bg.color = 0xFF110000;
                    gameName.text = '???';
                    gameName.color = white;
                    gameDesc.text = '???';
                    panela.color = black;
                    panelb.color = black;
                
                    selectedGame.color = black;

                    gameCover.visible = false;

                    FlxTween.tween(bg, {"alpha": 1}, 0.25);
                }
            });

            if (direction == 'down') {
                FlxTween.tween(iconGame, {"y": iconBaseY + 600}, 0.25, {
                    ease: FlxEase.sineIn,
                    onComplete: function() {
                        iconGame.y = iconBaseY - 600;
                        FlxTween.tween(iconGame, {"y": iconBaseY}, 0.25, {ease: FlxEase.sineIn});

                        iconGame.loadGraphic(Paths.image('icons/icon-placeholder'));
	                    iconFrameWidth = Std.int(iconGame.width * 0.5);
                        iconGame.loadGraphic(Paths.image('icons/icon-placeholder'), true, iconFrameWidth, Std.int(iconGame.height));
                    }
                });
                FlxTween.tween(selectedGame, {"y": panelBaseY + 600}, 0.25, {
                    ease: FlxEase.sineOut,
                    onComplete: function() {
                        selectedGame.y = panelBaseY - 600;
                        FlxTween.tween(selectedGame, {"y": panelBaseY}, 0.25, {ease: FlxEase.sineIn, onComplete: moving = false});
                    }
                });
            } else {
                FlxTween.tween(iconGame, {"y": iconBaseY - 600}, 0.25, {
                    ease: FlxEase.sineIn,
                    onComplete: function() {
                        iconGame.y = iconBaseY + 600;
                        FlxTween.tween(iconGame, {"y": iconBaseY}, 0.25, {ease: FlxEase.sineIn});

                        iconGame.loadGraphic(Paths.image('icons/icon-placeholder'));
	                    iconFrameWidth = Std.int(iconGame.width * 0.5);
                        iconGame.loadGraphic(Paths.image('icons/icon-placeholder'), true, iconFrameWidth, Std.int(iconGame.height));
                    }
                });
                FlxTween.tween(selectedGame, {"y": panelBaseY - 600}, 0.25, {
                    ease: FlxEase.sineOut,
                    onComplete: function() {
                        selectedGame.y = panelBaseY + 600;
                        FlxTween.tween(selectedGame, {"y": panelBaseY}, 0.25, {ease: FlxEase.sineIn, onComplete: moving = false});
                    }
                });
            }
        } else {
            bg.color = 0xFF110000;
            bg.alpha = 1;
            gameName.text = '???';
            gameName.color = white;
            gameDesc.text = '???';
            panela.color = black;
            panelb.color = black;
            selectedGame.color = black;

            iconGame.loadGraphic(Paths.image('icons/icon-placeholder'));
	        iconFrameWidth = Std.int(iconGame.width * 0.5);
            iconGame.loadGraphic(Paths.image('icons/icon-placeholder'), true, iconFrameWidth, Std.int(iconGame.height));
        }
    }
}

var transitioningToGame:Bool = false;

function onUpdate() {
    gamepad = FlxG.gamepads.lastActive;

    if (gamepad != null) var leftStickY:Float = gamepad.getYAxis(19) else var leftStickY:Float = 0;

    if (controls.BACK && !transitioningToGame) {
        FlxG.sound.music.stop();
        FlxG.sound.playMusic(Paths.music("freakyMenu"), 0.7, true);
        FlxG.switchState(new MainMenuState());
    }

    if (FlxG.keys.justPressed.UP || FlxG.keys.justPressed.W) {
        if (!transitioningToGame && !moving) selectGame((curGame == 0 ? (initiativeGames.length - 1) : curGame - 1), 'down');
    }
    if (FlxG.keys.justPressed.DOWN || FlxG.keys.justPressed.S) {
        if (!transitioningToGame && !moving) selectGame((curGame == initiativeGames.length - 1 ? 0 : curGame + 1), 'up');
    }

    if (gamepad != null) {
        if ((!transitioningToGame && !moving) && (gamepad.justPressed.DPAD_UP || (leftStickY <= -0.5))) selectGame((curGame == 0 ? (initiativeGames.length - 1) : curGame - 1), 'down');
        if ((!transitioningToGame && !moving) && (gamepad.justPressed.DPAD_DOWN || (leftStickY >= 0.5))) selectGame((curGame == initiativeGames.length - 1 ? 0 : curGame + 1), 'up');
        if ((!transitioningToGame && !moving) && (gamepad.justPressed.X)) infoShit();
    }

    #if mobile
    for (swipe in FlxG.swipes) {
        if (swipe.degrees <= -45 && swipe.degrees >= -135) selectGame((curGame == 0 ? (initiativeGames.length - 1) : curGame - 1), 'down');
        if (swipe.degrees <= 135 && swipe.degrees >= 45) selectGame((curGame == initiativeGames.length - 1 ? 0 : curGame + 1), 'up');
    }

    for (touch in FlxG.touches.list) {
        if (touch.justPressed && touch.overlaps(backButton) && !transitioningToGame && !moving) {
            FlxG.sound.music.stop();
            FlxG.sound.playMusic(Paths.music("freakyMenu"), 0.7, true);
            FlxG.switchState(new MainMenuState());
        }
        if (touch.justPressed && touch.overlaps(selectedGame)) FlxG.switchState(new ScriptedState("initiative/" + initiativeGames[curGame].state));
        if (touch.justPressed && touch.overlaps(infoButton) && !transitioningToGame && !moving) infoShit();
    }
    #end

    if (FlxG.mouse.overlaps(iconGame) && !transitioningToGame) {
        selectedGame.scale.set(0.475, 0.475);
        iconGame.scale.set(1.1, 1.1);
        if (FlxG.mouse.justPressed) doTheTransition();
    } else if (!transitioningToGame) {
        selectedGame.scale.set(0.5, 0.5);
        iconGame.scale.set(1, 1);
    }

    if (FlxG.mouse.overlaps(backButton) && !transitioningToGame && !moving) {
        backButton.scale.set(0.55, 0.55);
        if (FlxG.mouse.justPressed && !transitioningToGame && !moving) {
            FlxG.sound.music.stop();
            FlxG.sound.playMusic(Paths.music("freakyMenu"), 0.7, true);
            FlxG.switchState(new MainMenuState());
        }
    } else if (!transitioningToGame) {
        backButton.scale.set(0.5, 0.5);
    }

    if (FlxG.mouse.overlaps(infoButton) && !transitioningToGame && !moving) {
        infoButton.scale.set(1.05, 1.05);
        if (FlxG.mouse.justPressed && !transitioningToGame && !moving) {
            infoShit();
        }
    } else if (!transitioningToGame) {
        infoButton.scale.set(1, 1);
    }

    if (FlxG.keys.justPressed.TAB && !transitioningToGame) {
        infoShit();
    }

    if (controls.ACCEPT && !transitioningToGame) doTheTransition();
}

function doTheTransition() {
    #if !mobile
    transitioningToGame = true;
    FlxTween.tween(FlxG.sound.music, {"volume": 0}, 1);

    FlxTween.tween(panela, {"x": panela.x + 500}, 0.5);
    FlxTween.tween(gameCover, {"x": gameCover.x + 600}, 0.6);

    FlxTween.tween(panelb, {"x": panelb.x - 500}, 0.5);
    FlxTween.tween(gameName, {"x": gameName.x - 600}, 0.6);
    FlxTween.tween(gameDesc, {"x": gameDesc.x - 600}, 0.65);

    FlxTween.tween(iconGame.scale, {"x": 2, "y": 2}, 1);
    FlxTween.tween(FlxG.camera, {"zoom": 3, "alpha": 0}, 1, {
        onComplete: function() {
            FlxG.save.data.initiative.curPlayedGames.push(initiativeGames[curGame].name);
            FlxG.switchState(new ScriptedState("initiative/" + initiativeGames[curGame].state));
        }
    });
    #end
    #if mobile
    FlxG.save.data.initiative.curPlayedGames.push(initiativeGames[curGame].name);
    trace(initiativeGames[curGame].state);
    FlxG.switchState(new ScriptedState("initiative/" + initiativeGames[curGame].state));
    #end
}

function infoShit() {
    openSubState(new ScriptedSubstate("InitiativeInfoSubstate"));
}

function getGameInfo() {
    var info = initiativeGames[curGame].info;
    return info;
}

function hideCover() {
    FlxTween.tween(gameCover, {"angle": 0, "x": 600}, 0.25, {
        ease: FlxEase.quadOut,
        onComplete: function() {
            gameCover.alpha = 0.001;
        }
    });
}

function showCover() {
    gameCover.alpha = 1;
    FlxTween.tween(gameCover, {"angle": 0, "x": 800}, 0.25, {ease: FlxEase.quadOut});
}