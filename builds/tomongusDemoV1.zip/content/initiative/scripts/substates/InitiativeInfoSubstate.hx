var infoStuff;
var infoCamera;
var canDoStuff = false;

var imtoolazytodosomecomplicatedshit = {
    stuff: -2.5
}
var shader;
var backButton;

function onCreate() {
    infoCamera = new FlxCamera();
	infoCamera.bgColor = 0x88000000;
    infoCamera.alpha = 0;
    FlxG.cameras.add(infoCamera, false);

    var frag:String = Paths.getTextFromFile('shaders/round.frag');
    shader = new FlxRuntimeShader(frag);
    shader.setFloat('depth',imtoolazytodosomecomplicatedshit.stuff);
    infoCamera.filters = [new openfl.filters.ShaderFilter(shader)];

    infoStuff = FlxG.state.scriptGroup.members[0].executeFunc('getGameInfo');

    var bgA = new FlxSprite(0, 0).makeGraphic(600, 600, 0xFF000000);
    bgA.x = FlxG.width / 2 - bgA.width / 2;
    var bgB = new FlxSprite(0, 25).makeGraphic(550, 550, infoStuff.color * 0.75);
    bgB.x = FlxG.width / 2 - bgB.width / 2;
    var bgC = new FlxSprite(100, 100).makeGraphic(FlxG.width - 200, FlxG.height - 200, 0xFF000000);
    var bgD = new FlxSprite(125, 125).makeGraphic(FlxG.width - 250, FlxG.height - 250, infoStuff.color);

    gameCover = new FlxSprite();
	gameCover.loadGraphic(Paths.image('menu/initiative/selection/games/' + infoStuff.image));
    gameCover.updateHitbox();
    gameCover.scale.set(0.5, 0.5);
    gameCover.antialiasing = false;
    gameCover.screenCenter();
    gameCover.x = 800;
    gameCover.angle = 5;

    nameText = new FlxText(0, 50, 0, infoStuff.name, 20);
    nameText.x = FlxG.width / 2 - nameText.width / 2;
    descText = new FlxText(150, 150, 500, infoStuff.description, 20);

    backButton = new FlxSprite(1150, 15).loadGraphic(Paths.image('menu/common/reset'));
    backButton.scale.set(0.5, 0.5);
    backButton.updateHitbox();

    for (text in [descText, nameText]) {
        text.setFormat(Paths.font('vcr.ttf'), 20, FlxColor.WHITE, 'center');
	    text.borderStyle = FlxTextBorderStyle.OUTLINE;
	    text.borderColor = FlxColor.BLACK;
	    text.borderSize = 2;
    }

    for (obj in [bgA, bgB, bgC, bgD, gameCover, nameText, descText, backButton]) {
        obj.camera = infoCamera;
        add(obj);
    }

    FlxTween.tween(infoCamera, {"alpha": 1}, 0.25, {
        ease: FlxEase.quadOut,
        onComplete: function() {
            canDoStuff = true;
        }
    });

    FlxG.state.scriptGroup.members[0].executeFunc('hideCover');
    FlxTween.tween(gameCover, {"angle": 0, "x": 600}, 0.25, {ease: FlxEase.quadOut});

    FlxTween.tween(imtoolazytodosomecomplicatedshit, {"stuff": 1}, 0.25, {ease: FlxEase.backOut});
}

function onUpdate() {
    shader.setFloat('depth',imtoolazytodosomecomplicatedshit.stuff);
    infoCamera.filters = [new openfl.filters.ShaderFilter(shader)];
    if (controls.BACK && canDoStuff) {
        closeStuff();
    }
    #if mobile
    for (touch in FlxG.touches.list) {
        if (touch.justPressed && touch.overlaps(backButton)) {
            closeStuff();
        }
    }
    #end
    if (FlxG.mouse.overlaps(backButton)) {
        backButton.scale.set(0.55, 0.55);
        if (FlxG.mouse.justPressed) {
            FlxG.sound.music.stop();
            FlxG.sound.playMusic(Paths.music("freakyMenu"), 0.7, true);
            FlxG.switchState(new MainMenuState());
        }
    } else if (!transitioningToGame) {
        backButton.scale.set(0.5, 0.5);
    }
}

function closeStuff() {
    FlxG.state.scriptGroup.members[0].executeFunc('showCover');
    FlxTween.tween(gameCover, {"angle": 5, "x": 800}, 0.25, {ease: FlxEase.quadOut});

    FlxTween.tween(infoCamera, {"alpha": 0}, 0.25, {
        ease: FlxEase.quadOut,
        onComplete: function() {
            FlxG.cameras.remove(infoCamera, true);
            close();
        }
    });
    FlxTween.tween(imtoolazytodosomecomplicatedshit, {"stuff": -2.5}, 0.25, {ease: FlxEase.quadOut});
}