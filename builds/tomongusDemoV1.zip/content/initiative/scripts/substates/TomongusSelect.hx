import funkin.utils.FileUtil;
import funkin.FunkinAssets;
import openfl.net.FileFilter;
import openfl.net.FileReference;
import openfl.events.Event;
import sys.io.File;
import sys.FileSystem;
import haxe.io.BytesInput;
import haxe.zip.Reader;
import haxe.io.Path;
import flixel.StringTools;

var panel;
var textA;
var textB;

function onCreate() {
    loadTopLayer();

    #if !mobile
    FileUtil.browseForFile(
        {
            title: 'Load a Tomongus Pinball map pack!',
            typeFilter: new FileFilter("Tomongus Pinball Map Pack", "*.tomo")
        },
        function (file) {
            if (StringTools.endsWith(file, ".tomo")) {
                var bytes = FunkinAssets.getBytes(file);
                var input = new BytesInput(bytes);
                var files = Reader.readZip(input);

                if (FileSystem.exists("initiative/mods/tomongusModTemp"))
                    clearTempTomongus();

                if (!FileSystem.exists("initiative/mods/tomongusModTemp"))
                    FileSystem.createDirectory("initiative/mods/tomongusModTemp");

                for (zipfile in files) {
                    if (StringTools.endsWith(zipfile.fileName, "/")) {
                        FileSystem.createDirectory("initiative/mods/tomongusModTemp/" + zipfile.fileName);
                        continue;
                    }
                    File.saveBytes("initiative/mods/tomongusModTemp/" + zipfile.fileName, zipfile.data);
                }

                FlxG.save.data.initiative.pinball.path = 'initiative/mods/tomongusModTemp/';
                FlxG.save.data.initiative.pinball.mapPack = CoolUtil.coolTextFile('initiative/mods/tomongusModTemp/base.txt');
                goInGame();
            } else if (FunkinAssets.exists('initiative/mods/tomongus.tomo')) {
                bytes = FunkinAssets.getBytes("initiative/mods/tomongus.tomo");
                goInGameMobile(bytes);
            } else if (FunkinAssets.exists('initiative/tomongus.tomo')) {
                bytes = FunkinAssets.getBytes("initiative/tomongus.tomo");
                goInGameMobile(bytes);
            } else close();
        },
        function () {
            if (FunkinAssets.exists('initiative/mods/tomongus.tomo')) {
                bytes = FunkinAssets.getBytes("initiative/mods/tomongus.tomo");
                goInGameMobile(bytes);
            } else if (FunkinAssets.exists('initiative/tomongus.tomo')) {
                bytes = FunkinAssets.getBytes("initiative/tomongus.tomo");
                goInGameMobile(bytes);
            } else close();
        }
    );
    #end

    #if mobile
    var bytes = FunkinAssets.getBytes("initiative/tomongus.tomo");
    if (FunkinAssets.exists('initiative/mods/tomongus.tomo')) bytes = FunkinAssets.getBytes("initiative/mods/tomongus.tomo");
    goInGameMobile(bytes);
    #end
}

function loadTopLayer() {
    pinballMouse = new FlxSprite().loadGraphic(Paths.image('pinball/cursor'));
    pinballMouse.antialiasing = false;
    pinballMouse.scale.set(2, 2);
    #if mobile
    pinballMouse.visible = false;
    #end
    add(pinballMouse);
    var blackBarA = new FlxSprite().makeGraphic((FlxG.width - 256 * 3) / 3, FlxG.height, FlxColor.BLACK);
    add(blackBarA);
    var blackBarB = new FlxSprite(FlxG.width - blackBarA.width, 0).makeGraphic(((FlxG.width - 256 * 3) + 100) / 3, FlxG.height, FlxColor.BLACK);
    add(blackBarB);

    var frag:String = Paths.getTextFromFile('shaders/vhs.frag');
    shader = new FlxRuntimeShader(frag);
    shader.setInt('uniform',3);
    shader.setFloat('uInterlace',3);
    if (ClientPrefs.shaders) pinballMouse.camera.filters = [new openfl.filters.ShaderFilter(shader)];
}

function onUpdate() {
    pinballMouse.x = FlxG.mouse.x;
    pinballMouse.y = FlxG.mouse.y;

    if (controls.BACK) {
        close();
    }
}

function goInGame() {
    FlxG.save.data.initiative.pinball.mapNum = 0;

    var mapPack = FlxG.save.data.initiative.pinball.mapPack;
    FlxG.sound.music.stop();
    FlxG.save.data.initiative.pinball.map = mapPack[FlxG.save.data.initiative.pinball.mapNum];
    FlxG.switchState(()->{
        new ScriptedState("initiative/pinball/PlayState");
    });
}

function goInGameMobile(zip) {
    var input = new BytesInput(zip);

    var files = Reader.readZip(input);

    if (!FileSystem.exists("initiative/mods/tomongusModTemp"))
        FileSystem.createDirectory("initiative/mods/tomongusModTemp");

    for (file in files) {
        if (StringTools.endsWith(file.fileName, "/")) {
            FileSystem.createDirectory("initiative/mods/tomongusModTemp/" + file.fileName);
            continue;
        }
        File.saveBytes("initiative/mods/tomongusModTemp/" + file.fileName, file.data);
    }

    FlxG.save.data.initiative.pinball.mapNum = 0;

    FlxG.save.data.initiative.pinball.path = "initiative/mods/tomongusModTemp/";
    FlxG.save.data.initiative.pinball.mapPack = CoolUtil.coolTextFile('initiative/mods/tomongusModTemp/base.txt');

    var mapPack = FlxG.save.data.initiative.pinball.mapPack;
    FlxG.sound.music.stop();
    FlxG.save.data.initiative.pinball.map = mapPack[FlxG.save.data.initiative.pinball.mapNum];
    FlxG.switchState(()->{
        new ScriptedState("initiative/pinball/PlayState");
    });
}

function clearTempTomongus(?overrideFolder = null) {
    var path = 'initiative/mods/tomongusModTemp/';
    if (overrideFolder != null) path = overrideFolder;
    var paths = ['initiative/mods/tomongusModTemp/'];
    if (FileSystem.exists(path) && FileSystem.isDirectory(path)) {
        var entries = FileSystem.readDirectory(path);
        for (entry in entries) {
            var fullPath = path + entry;
            if (FileSystem.isDirectory(fullPath)) {
                clearTempTomongus(fullPath + '/');
                FileSystem.deleteDirectory(fullPath);
            } else {
                FileSystem.deleteFile(fullPath);
            }
        }
    }
}
