import funkin.states.StoryMenuState;

// Selection Menu
var bg;
var selectedGame;
var iconGame;
var panela;
var panelb;

var gameName;
var gameDesc;
var gameCover;

var games = [
    {
        name: "Dave's Dream Job",
        nameTrans: "daveName",
        description: "Dave needs a job, so obviously he joined MIRA! Though, some impostors are lurking around! Can he survive?",
        descriptionTrans: "daveDesc",
        image: "dave",
        colorA: 0xFF8888FF,
        colorB: 0xFF6666FF
    }
];
var curGame = 0;

function onLoad() {
    songStartCallback = () -> {
		return Function_Stop;
	}
    FlxG.sound.playMusic(Paths.music("breakfast"), 0.7, true);
}

function onCreatePost() {
    camGame.visible = false;

    dadGroup.visible = false;
    boyfriendGroup.visible = false;
    gfGroup.visible = false;
    pet.visible = false;

    scoreTxt.visible = false;
    game.playFields.members[0].visible = false;
    game.playFields.members[1].visible = false;
    healthBar.visible = false;
    iconP1.visible = false;
    iconP2.visible = false;

    switch (songName) {
        case 'initiativeMenu': makeInitiativeSelectionMenu();
    }
}

function onUpdatePost() {
    snapCamToPos(0, 0);
}

// Selection Menu again
function makeInitiativeSelectionMenu() {
    bg = new FlxSprite(0, 0);
	bg.makeGraphic(FlxG.width, FlxG.height, 0xFF111111);
    bg.updateHitbox();
    bg.scrollFactor.set();

    selectedGame = new FlxSprite();
	selectedGame.loadGraphic(Paths.image('menu/initiative/selection/tab'));
    selectedGame.updateHitbox();
    selectedGame.scale.set(0.5, 0.5);
    selectedGame.screenCenter();

    iconGame = new FlxSprite();
	iconGame.loadGraphic(Paths.image('icons/icon-dave'));
	iconFrameWidth = Std.int(iconGame.width * 0.5);
	iconGame.loadGraphic(Paths.image('icons/icon-dave'), true, iconFrameWidth, Std.int(iconGame.height));
	iconGame.animation.add('idle', [0], 0, false);
	iconGame.animation.play('idle');
	iconGame.scrollFactor.set();
    iconGame.screenCenter();

    panela = new FlxSprite();
	panela.loadGraphic(Paths.image('menu/initiative/selection/panel'));
    panela.updateHitbox();
    panela.scale.set(0.5, 0.5);
    panela.screenCenter();
    panela.x = 650;

    panelb = new FlxSprite();
	panelb.loadGraphic(Paths.image('menu/initiative/selection/panel'));
    panelb.updateHitbox();
    panelb.scale.set(-0.65, 0.65);
    panelb.screenCenter();
    panelb.x = -300;

    gameName = new FlxText(50, 100, 300, Lang.str(games[curGame].nameTrans, games[curGame].name), 42);
	gameName.setFormat(Paths.font('vcr.ttf'), 42, FlxColor.WHITE, 'center');
	gameName.borderStyle = FlxTextBorderStyle.OUTLINE;
	gameName.borderColor = FlxColor.BLACK;
	gameName.borderSize = 2;

    gameDesc = new FlxText(50, 300, 300, Lang.str(games[curGame].descriptionTrans, games[curGame].description), 42);
	gameDesc.setFormat(Paths.font('vcr.ttf'), 30, FlxColor.WHITE, 'center');
	gameDesc.borderStyle = FlxTextBorderStyle.OUTLINE;
	gameDesc.borderColor = FlxColor.BLACK;
	gameDesc.borderSize = 2;

    gameCover = new FlxSprite();
	gameCover.loadGraphic(Paths.image('menu/initiative/selection/games/' + games[curGame].image));
    gameCover.updateHitbox();
    gameCover.scale.set(0.5, 0.5);
    gameCover.antialiasing = false;
    gameCover.screenCenter();
    gameCover.x = 800;
    gameCover.angle = 5;

    for (obj in [bg, selectedGame, iconGame, panela, panelb, gameName, gameDesc, gameCover]) {
        add(obj);
        obj.camera = camHUD;
    }

    selectGame(0);
}

function selectGame(num:Int = 0) {
    gameName.text = Lang.str(games[curGame].nameTrans, games[curGame].name);
    gameName.color = games[curGame].colorA;
    gameDesc.text = Lang.str(games[curGame].descriptionTrans, games[curGame].description);
    gameDesc.color = games[curGame].colorA;
    panela.color = games[curGame].colorB;
    panelb.color = games[curGame].colorB;
    selectedGame.color = games[curGame].colorA;
}

function onUpdate() {
    if (controls.BACK) {
        if (songName == 'initiativeMenu') {
            FlxG.sound.music.stop();
            FlxG.sound.playMusic(Paths.music("freakyMenu"), 0.7, true);
            FlxG.switchState(new StoryMenuState());
        }
    }
}